bienvenida = """
*******************************************
Bienvenidos al gestor de notas de UTEC
*******************************************
"""

menu = """
(1) si desea seleccionar un curso.
(2) si desea agregar un curso.
(3) si desea ingresar alumnos a un curso.
(4) si desea agregar notas de alumnos.
(5) si desea mostrar notas promedio de cursos.
(6) para salir.
"""

menucursos = """
Seleccione el código del curso a trabajar o
Ingrese 0 si desea volver al menú anterior:
"""
