import recursos

def menuprincipal():
    print(recursos.bienvenida)
    print(recursos.menu)



def loaddata(nombre, dicpcurso, listcurso):
    file = open(nombre, "r")
    while True:
        dicpcurso = {}
        theline = file.readline().rstrip()
        if len(theline) == 0:
            break
        lista = theline.split(',')
        dicpcurso['codigo']=lista[0]
        dicpcurso['nombre']=lista[1]
        listcurso.append(dicpcurso)
    file.close()


def listadocursos():

    dic_cursos = {}
    cursos = []

    loaddata('files/cursos.txt',dic_cursos, cursos)
    cabecera = '{:<15}  {:>15} '.format('Código', 'Nombre')
    linea = '----------------------------------------'
    print(cabecera)
    print(linea)
    for dic in cursos:
        registro = '{:<15}  {:>15} '.format(dic['codigo'], dic['nombre'])
        print(registro)

    n = input(recursos.menucursos)

    for dic in cursos:
        if n == dic['codigo']:
            curso = dic['nombre']
            print('curso seleccionado: {}'.format(curso))

        elif n == '0':
            main()


def main():

    menuprincipal()
    n = int(input('Ingrese la opción:'))

    if n == 1:
        listadocursos()
    elif n == 2:
        pass
    elif n == 3:
        pass
    elif n == 4:
        pass
    elif n == 5:
        pass
    elif n == 6:
        print("gracias por usar el gestor de notas de UTEC.")

main()
